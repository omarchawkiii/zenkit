<?php

return [


    'Name' => 'Nom',
    'Email Address' => 'Email',
    'age'=>'Age group',
    'tranch1'=>'Under 12 years old',
    'tranch2'=>'12 to 20 years old',
    'tranch3'=>'21 to 50 years old',
    'tranch4'=>'over 50 years old',
    'Confirm_password' => 'Confirm Password',


    'sign'=>'Sign Up',
    'logout'=>'Log Out',
    'search' => 'Search',
    'sendp' => 'Send Password Reset Link',
    'resetp'=>'Reset Password',

    'login'=>'Login',
    'email'=>'Email Address',
    'password'=>'Password',
    'remember'=> 'Remember Me',
    'forgot' => 'Forgot Your Password ?',





    "Welcome Back !" => "Content de te revoir !" ,
    "Sign in to continue to Invoika." => "Connectez-vous pour continuer ",
    "Password" => "Mot de passe",
    "Forgot Your Password?" => "Mot de passe oublié?",
    "Remember Me" => "Souviens-toi de moi",
    "Log In" => "Se connecter",
    "Sign in with" => "Se connecter avec",
    "Don't have an account ?" => "Vous n'avez pas de compte ?",
    "Signup now" => "S'inscrire maintenant",
    "Our task must be to free widening circle" => "    Notre tâche doit être de libérer le cercle qui s'élargit",
    "Companyn ame" => "Nom d'entreprise",
    "Confirm Password" =>"Confirmez le mot de passe" ,
    "Register" => "S'inscrir",
    "Signin now" => "Connectez vous maintenant",
    "you have an account ?" => "Vous avez un compte ? " ,
    "Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one." => "Mot de passe oublié? Aucun problème. Indiquez-nous simplement votre adresse e-mail et nous vous enverrons par e-mail un lien de réinitialisation de mot de passe qui vous permettra d'en choisir un nouveau.",
    "Send Password Reset Link" => "Envoyer le lien de réinitialisation du mot de passe" ,
    "Before proceeding, please check your email for a verification link."=>"Avant de continuer, veuillez vérifier votre courrier électronique pour un lien de vérification.",
    "If you did not receive the email"=> "Si vous n'avez pas reçu l'e-mail",
    "click here to request another"=> "cliquez ici pour en demander un autre",
    "A fresh verification link has been sent to your email address." => "Un nouveau lien de vérification a été envoyé à votre adresse e-mail." ,
    "Reset password." => "Réinitialiser le mot de passe." ,
    "Facilitez la facturation, simplifiez la réussite" => "Facilitez la facturation, simplifiez la réussite",
    "Simplifiez la facturation, maximisez vos gains" => "Simplifiez la facturation, maximisez vos gains",
];
