<?php

return [


    'Name' =>'Name' ,
    'Email Address' =>'Email Address' ,
    'age'=>'age',
    'tranch1'=>'tranch1',
    'tranch2'=>'tranch2',
    'tranch3'=>'tranch3',
    'tranch4'=>'tranch4',
    'Confirm_password' =>'Confirm_password' ,


    'sign'=>'sign',
    'logout'=>'logout',
    'search' =>'search' ,
    'sendp' =>'sendp' ,
    'resetp'=>'resetp',

    'login'=>'login',
    'email'=>'email',
    'password'=>'password',
    'remember'=>'remember',
    'forgot' =>'forgot' ,





    "Welcome Back !" =>"Welcome Back !" ,
    "Sign in to continue to Invoika." =>"Sign in to continue to Invoika." ,
    "Password" =>"Password" ,
    "Forgot Your Password?" =>"Forgot Your Password?" ,
    "Remember Me" =>"Remember Me" ,
    "Log In" =>"Log In" ,
    "Sign in with" =>"Sign in with" ,
    "Don't have an account ?" =>"Don't have an account ?" ,
    "Signup now" =>"Signup now" ,
    "Our task must be to free widening circle" =>"Our task must be to free widening circle" ,
    "Companyn ame" =>"Companyn ame" ,
    "Confirm Password" =>"Confirm Password" ,
    "Register" =>"Register" ,
    "Signin now" =>"Signin now" ,
    "you have an account ?" =>"you have an account ?" ,
    "Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one." =>"Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one." ,
    "Send Password Reset Link" =>"Send Password Reset Link" ,
    "Before proceeding, please check your email for a verification link."=>"Before proceeding, please check your email for a verification link.",
    "If you did not receive the email"=>"If you did not receive the email",
    "click here to request another"=>"click here to request another",
    "A fresh verification link has been sent to your email address." =>"A fresh verification link has been sent to your email address." ,
    "Reset password." =>"Reset password." ,
    "Facilitez la facturation, simplifiez la réussite" =>"Facilitez la facturation, simplifiez la réussite" ,
    "Simplifiez la facturation, maximisez vos gains" =>"Simplifiez la facturation, maximisez vos gains" ,
];
